<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="/assets/admin/components.chunk.css?v=<?php echo e($version); ?>">
    <link rel="stylesheet" href="/assets/admin/umi.css?v=<?php echo e($version); ?>">
    <link rel="stylesheet" href="/assets/admin/custom.css?v=<?php echo e($version); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <title><?php echo e($title); ?></title>
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,400i,600,700"> -->
    <script>window.routerBase = "/";</script>
    <script>
        window.settings = {
            title: '<?php echo e($title); ?>',
            theme: {
                sidebar: '<?php echo e($theme_sidebar); ?>',
                header: '<?php echo e($theme_header); ?>',
                color: '<?php echo e($theme_color); ?>',
            },
            version: '<?php echo e($version); ?>',
            background_url: '<?php echo e($background_url); ?>',
            logo: '<?php echo e($logo); ?>',
            secure_path: '<?php echo e($secure_path); ?>'
        }
    </script>
</head>

<body>
<div id="root"></div>
<script src="/assets/admin/vendors.async.js?v=<?php echo e($version); ?>"></script>
<script src="/assets/admin/components.async.js?v=<?php echo e($version); ?>"></script>
<script src="/assets/admin/umi.js?v=<?php echo e($version); ?>"></script>
</body>

</html>
<?php /**PATH /www/wwwroot/test.4gsieure.net/resources/views/admin.blade.php ENDPATH**/ ?>